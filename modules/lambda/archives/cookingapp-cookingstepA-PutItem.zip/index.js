import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { PutCommand, DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";
import { randomUUID } from "crypto";

const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);

export const handler = async (event) => {
  // TODO implement
  
  const command = new PutCommand({
    TableName: "cookingstepA",
    Item: {
      cookingstepId: randomUUID(),
      cookingsteptext: event.cookingsteptext,
      cookingstepindex: event.cookingstepindex
    }
  });

  const response = await docClient.send(command);


  return response;
};
